import { api } from "./client";

export const getPokemons = async () => {
    const response = await api.get('/pokemons');
    return response.data;
  };

  export const getPokemonById = async (id) => {
    const response = await api.get(`/pokemons/${id}`);
    return response.data;
  };

  export const createPokemon = async (pokemon) => {
    const response = await api.post('/pokemons', pokemon);
    return response.data;
  };

  export const updatePokemon = async (id, pokemon) => {
    const response = await api.put(`/pokemons/${id}`, pokemon);
    return response.data;
  };

  export const deletePokemon = async (id) => {
    const response = await api.delete(`/pokemons/${id}`);
    return response.data;
  };

  export const getPokemonByName = async (name) => {
    const response = await api.get(`/pokemons/name/${name}`);
    return response.data;
  };

